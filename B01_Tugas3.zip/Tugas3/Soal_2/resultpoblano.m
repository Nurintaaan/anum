warning off;
diary('result_poblano.txt');
mainpoblano();
diary off;