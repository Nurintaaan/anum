%INSTALL_POBLANO   Script to install Poblano path.
%
%MATLAB Poblano Toolbox.
%Copyright 2009-2012, Sandia Corporation.

addpath(pwd)
savepath

 
